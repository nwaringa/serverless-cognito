serverless-cognito
==================
Authenticate your users through Cognito, Lambda and API Gateway. The script will set a local cookie in the browser and prompt for reauthentication by the user if needed. The code will also be available in the Serverless Application repository soon. 

Installation
------------

Copy the Lambda code to a Python 3.6 function or use the attached SAM template.

Contact
-------

In case of questions or bugs, please raise an issue or reach out to @marekq!
